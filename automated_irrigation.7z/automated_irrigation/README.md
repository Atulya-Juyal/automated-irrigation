23BCE10984 Atulya Juyal
23BCE10955 Shoyuj Sharma
23BCE10901 Avinash Gautam
23BCE10971 Aryan Sandeep Patil
23BCE109   Shaurya